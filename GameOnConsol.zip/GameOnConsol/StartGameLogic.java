package GameOnConsol.GameLogic;

import GameOnConsol.MazeAlgorithm.MazeAlgorithm;

import java.util.Scanner;

public class StartGameLogic {
    private MazeAlgorithm maze = new MazeAlgorithm();
    public StartGameLogic(Scanner input){
        System.out.print("\033[H\033[J");
        System.out.println(maze.toString());
        new Game(maze, input);
        }
    }
