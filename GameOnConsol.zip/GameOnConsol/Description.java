package GameOnConsol.SetWindow;

import GameOnConsol.Exeptions.ValueException;

import java.util.Scanner;

public class Description {
    private String playerInput;
    private boolean b = true;
    public Description(Scanner input){
        System.out.print("\033[H\033[J");
        System.out.println("""
            u can move on . and E
            u are P
            buttons in game
            w - up
            s - down
            d - right
            a - left
            Enter 0 to return to Main Menu
            """);
        while (b){
            playerInput = input.next();
            if (playerInput.equals("0")){
                b = false;
                new SetupOfMainMenu();
            }
            else {
                new ValueException();
            }
        }
    }
}
