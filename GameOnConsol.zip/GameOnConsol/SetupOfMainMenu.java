package GameOnConsol.SetWindow;

import GameOnConsol.Exeptions.ValueException;
import GameOnConsol.GameLogic.StartGameLogic;

import java.util.Scanner;

public class SetupOfMainMenu {
    private final Scanner input = new Scanner(System.in);
    public SetupOfMainMenu(){
        System.out.print("\033[H\033[J");
        System.out.println("Enter 1 to begin\nEnter 2 to see description\nEnter 3 to exit");
        switch (input.next()){
            case "1":
                new StartGameLogic(input);
                break;
            case "2":
                new Description(input);
                break;
            case "3":
                System.exit(0);
            default:
                new ValueException();
        }
    }
}