package GameOnConsol.MazeAlgorithm;

public class MazeAlgorithm {
    private final int minValue = 5;
    private final int maxValue = 16;
    private final int lengthMaze = (minValue + (int) (Math.random() * (maxValue - minValue + 1))) * 2 - 1;
    private final int heightMaze = minValue + (int) (Math.random() * (maxValue - minValue + 1)) * 2;
    private String[][] maze = new String[heightMaze][lengthMaze];
    public MazeAlgorithm(){
        maze[0][0] = "E";
        for (int i = 1; i < lengthMaze; i++){
            maze[0][i] = ".";
        }
        for (int i = 1; i < heightMaze - 1; i += 2){
            for (int j = 0; j < lengthMaze; j++){
                maze[i][j] = "#";
            }}
        for (int i = 2; i < heightMaze; i += 2){
            for (int j = 0; j < lengthMaze - 2; j += 2){
                maze[i][j] = ".";
                maze[i][j + 1] = "#";
            }
            maze[i][maze[i].length - 1] = ".";
        }

        for (int i = 2; i < heightMaze; i += 2){
            for (int j = 0; j < lengthMaze - 2; j += 2){
                int randomWallClean = (int) Math.round(Math.random());
                switch (randomWallClean) {
                    case 1:
                        maze[i - 1][j] = ".";
                        break;
                    case 0:
                        maze[i][j + 1] = ".";
                        break;
                }
            }
            maze[i - 1][maze[i].length - 1] = ".";
        }
        for (int i = 0; i < lengthMaze - 1; i++){
            int randomWallClean = (int) Math.round(Math.random());
            if (randomWallClean == 1){
                    maze[heightMaze - 2][i] = ".";
            }
            maze[heightMaze - 1][i] = ".";
        }
        maze[heightMaze - 1][lengthMaze - 1] = "P";
        maze[heightMaze- 2][lengthMaze - 1] = "#";
    }
    @Override
    public String toString(){
        String mazeStr = "";
        for (int i = 0; i < heightMaze; i++){
            for (int j = 0; j < lengthMaze; j++){
                mazeStr += maze[i][j];
            }
            mazeStr += "\n";
        }
        return mazeStr;
    }
    public String[][] getMaze(){
        return maze;
    }
    public void setMaze(String[][] newMaze){
        maze = newMaze;
    }
}
