package GameOnConsol;

import GameOnConsol.SetWindow.*;

public class Play{
    public static void main(String[] args){
        new SetupOfMainMenu();
    }
}
