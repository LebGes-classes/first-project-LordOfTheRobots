package GameOnConsol.GameLogic;

import GameOnConsol.MazeAlgorithm.MazeAlgorithm;

public class Movement {
    private String[][] blueprintOfMaze;
    public Movement(MazeAlgorithm maze, int[] newPlayerPosition, Integer[] lastPlayerPosition){
        blueprintOfMaze = maze.getMaze();
        if ((newPlayerPosition[0] < blueprintOfMaze.length && newPlayerPosition[0] >= 0 && newPlayerPosition[1] < blueprintOfMaze[0].length && newPlayerPosition[1] >= 0)
                && !(blueprintOfMaze[newPlayerPosition[0]][newPlayerPosition[1]].equals("#"))){
            System.out.println("a");
            blueprintOfMaze[newPlayerPosition[0]][newPlayerPosition[1]] = "P";
            blueprintOfMaze[lastPlayerPosition[0]][lastPlayerPosition[1]] = ".";
            maze.setMaze(blueprintOfMaze);
            lastPlayerPosition[0] = newPlayerPosition[0];
            lastPlayerPosition[1] = newPlayerPosition[1];
        }
    }
}