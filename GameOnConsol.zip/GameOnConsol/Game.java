package GameOnConsol.GameLogic;

import GameOnConsol.Exeptions.ValueException;
import GameOnConsol.MazeAlgorithm.MazeAlgorithm;

import java.util.Scanner;

public class Game {
    private String[][] blueprintOfMaze;
    private String move;
    private Integer[] playerPosition;
    private boolean b = true;

    public Game(MazeAlgorithm maze, Scanner input){
        blueprintOfMaze = maze.getMaze();
        playerPosition = new Integer[]{blueprintOfMaze.length - 1, blueprintOfMaze[0].length - 1};

        while (b){
            move = input.next();
            switch (move) {
                case "w":
                    new Movement(maze, new int[]{playerPosition[0] - 1, playerPosition[1]}, playerPosition);
                    break;
                case "s":
                    new Movement(maze, new int[]{playerPosition[0] + 1, playerPosition[1]}, playerPosition);
                    break;
                case "a":
                    new Movement(maze, new int[]{playerPosition[0], playerPosition[1] - 1}, playerPosition);
                    break;
                case "d":
                    new Movement(maze, new int[]{playerPosition[0], playerPosition[1] + 1}, playerPosition);
                    break;
                default:
                    new ValueException();
            }
            System.out.print("\033[H\033[J");
            System.out.println(maze.toString());
            isEnd(input);
    }
    }
    private void isEnd(Scanner input){
        String answer;
        if (playerPosition[0] == 0 && playerPosition[1] == 0){
            System.out.print("\033[H\033[J");
            b = false;
            System.out.println("Do u wanna play again?\n[Y/N]");
            while (true){
                answer = input.next().toUpperCase();
                switch (answer){
                    case "N":
                        System.exit(0);
                    case "Y":
                        new StartGameLogic(input);
                    default:
                        new ValueException();
                }
            }
        }
    }
}