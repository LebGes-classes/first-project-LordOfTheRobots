package GameOnConsol.Exeptions;

public class ValueException {
    public ValueException(){
        System.out.println("You entered wrong value try again");
    }
}